'use strict';

module.exports = {
	app: {
		title: 'boss',
		description: 'desboss',
		keywords: 'MongoDB, Express, AngularJS, Node.js'
	},
	port: process.env.PORT || 3000,
	templateEngine: 'swig',
	sessionSecret: 'MEAN',
	sessionCollection: 'sessions',
	assets: {
		lib: {
			css: [
				'public/lib/bootstrap/dist/css/bootstrap.css',
				'public/lib/clockface-1.0.1/css/clockface.css',
				//'public/lib/imageCaption/css/default.css',
				'public/lib/imageCaption/css/component.css',
				//'public/lib/bootstrap/dist/css/bootstrap-theme.css',
				'public/lib/angular-ui-grid/ui-grid.css',
				'public/lib/bootstrap-material-design/dist/css/roboto.css',
				'public/lib/bootstrap-material-design/dist/css/material.css',
				'public/lib/bootstrap-material-design/dist/css/ripples.css',
				'public/lib/fontawesome/css/font-awesome.css',
				'public/lib/odometer/themes/odometer-theme-minimal.css'
				
			],
			js: [
				'public/lib/angular/angular.js',
				'public/lib/angular-resource/angular-resource.js',
				'public/lib/angular-cookies/angular-cookies.js', 
				'public/lib/angular-animate/angular-animate.js',
				'public/lib/angular-touch/angular-touch.js', 
				'public/lib/angular-sanitize/angular-sanitize.js', 
				'public/lib/angular-ui-router/release/angular-ui-router.js',
				'public/lib/angular-ui-utils/ui-utils.js',
				'public/lib/jquery/dist/jquery.js',
				'public/lib/bootstrap/dist/bootstrap.js',
				'public/lib/angular-bootstrap/ui-bootstrap-tpls.js',
				'public/lib/imageCaption/js/modernizr.custom.js',
				'public/lib/angular-ui-grid/ui-grid.js',
				'public/lib/ngmap/build/scripts/ng-map.js',
				

				'public/lib/arrive/src/arrive.js',
				'public/lib/bootstrap-material-design/dist/js/material.js',
				'public/lib/bootstrap-material-design/dist/js/ripples.js',
				'public/lib/clockface-1.0.1/js/clockface.js',
				'public/lib/odometer/odometer.js',
				'public/lib/angular-odometer-js/dist/angular-odometer.js'

			]
		},
		css: [
			'public/modules/**/css/*.css'
		],
		js: [
			'public/config.js',
			'public/application.js',
			'public/modules/*/*.js',
			'public/modules/*/*[!tests]*/*.js'
		],
		tests: [
			'public/lib/angular-mocks/angular-mocks.js',
			'public/modules/*/tests/*.js'
		]
	}
};