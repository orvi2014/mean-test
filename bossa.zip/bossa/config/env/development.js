'use strict';

module.exports = {
	db: 'mongodb://localhost/boss-dev',
	app: {
		title: 'boss - Development Environment'
	},
	facebook: {
		clientID: process.env.FACEBOOK_ID || '103504813321474',
		clientSecret: process.env.FACEBOOK_SECRET || 'd6f4a2fe338f13a13236242fccef431e',
		callbackURL: '/auth/facebook/callback'
	},
	twitter: {
		clientID: process.env.TWITTER_KEY || 'J0MC0uuAPtATTMjtfiy1ZqVH9',
		clientSecret: process.env.TWITTER_SECRET || 'iQ4WDpBYNxmi8XAZWpuzxCX7gIWluBBK9il3A7ACfT1744w7Ki',
		callbackURL: '/auth/twitter/callback'
	},
	google: {
		clientID: process.env.GOOGLE_ID || '1011840665216-0kpbelbcm6u3qihohjkuk9vv9bq7onpj.apps.googleusercontent.com',
		clientSecret: process.env.GOOGLE_SECRET || '15CduiAEd8x9Mg_rsoGGwTXt',
		callbackURL: '/auth/google/callback'
	},
	linkedin: {
		clientID: process.env.LINKEDIN_ID || '75yzktlbkwphc0',
		clientSecret: process.env.LINKEDIN_SECRET || 'PYDTMWJRpzKA1iGC',
		callbackURL: '/auth/linkedin/callback'
	},
	github: {
		clientID: process.env.GITHUB_ID || 'f926bf3ba625d17aed6d',
		clientSecret: process.env.GITHUB_SECRET || 'd7fad07e4e25c055b45312e03ad0695bade6bb6f',
		callbackURL: '/auth/github/callback'
	},
	mailer: {
		from: process.env.MAILER_FROM || 'MAILER_FROM',
		options: {
			service: process.env.MAILER_SERVICE_PROVIDER || 'MAILER_SERVICE_PROVIDER',
			auth: {
				user: process.env.MAILER_EMAIL_ID || 'MAILER_EMAIL_ID',
				pass: process.env.MAILER_PASSWORD || 'MAILER_PASSWORD'
			}
		}
	}
};
