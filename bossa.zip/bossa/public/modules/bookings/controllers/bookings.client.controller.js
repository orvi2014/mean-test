'use strict';

// Bookings controller
angular.module('bookings').controller('BookingsController', ['$scope', '$stateParams', '$location', 'Authentication', 'Bookings',
	function($scope, $stateParams, $location, Authentication, Bookings) {
		$scope.authentication = Authentication;

		
		// Create new Booking
		//this.create = function(restuarent,dishesb) {
		//	//---save or create booking ------
		//	var booking = new Bookings ({
		//		partySize: $scope.partySize,
		//		restuarent: restuarent._id,
		//		bookDateTime: $scope.dt,
		//		dishes : dishesb
		//	});
		//	
		//	booking.$save(function(response) {
		//	
		//	}, function(errorResponse) {
		//		$scope.error = errorResponse.data.message;
		//	});
		//	
		//};

		// Remove existing Booking
		$scope.remove = function(booking) {
			if ( booking ) { 
				booking.$remove();

				for (var i in $scope.bookings) {
					if ($scope.bookings [i] === booking) {
						$scope.bookings.splice(i, 1);
					}
				}
			} else {
				$scope.booking.$remove(function() {
					$location.path('bookings');
				});
			}
		};

		// Update existing Booking
		$scope.update = function() {
			var booking = $scope.booking;

			booking.$update(function() {
				$location.path('bookings/' + booking._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		$scope.gridOptions = {
			 enableSorting: true,
			enableFiltering: true,
			
			//showGridFooter: true,
			showColumnFooter: true,
			
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,

			columnDefs: [
			  {field: 'partySize', displayName: 'PartySize'},
			  {field: 'bookDateTime', displayName: 'BookDateTime'},
			 { name: 'more', displayName: 'More', cellTemplate: '<a data-ng-href="#!/bookings/{{row.entity._id}}" >more</a> ', enableFiltering: false, enableSorting: false}
			]    
		  };
		  
		// Find a list of booking
		$scope.find = function() {
			$scope.bookings = Bookings.query();
			$scope.gridOptions.data = $scope.bookings;	
		};
		

		// Find existing Booking
		$scope.findOne = function() {
			$scope.booking = Bookings.get({ 
				bookingId: $stateParams.bookingId
			});
		};
		
		
	}
]);