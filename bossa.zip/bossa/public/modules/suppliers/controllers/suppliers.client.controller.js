'use strict';

// Suppliers controller
angular.module('suppliers').controller('SuppliersController', ['$scope', '$stateParams', '$location', 'Authentication', 'Suppliers',
	function($scope, $stateParams, $location, Authentication, Suppliers) {
		$scope.authentication = Authentication;
		
		$scope.currentPage1 = 1; //for parallel view
		$scope.pageSize = 9;

		// Create new Supplier
		$scope.create = function() {
			// Create new Supplier object
			var supplier = new Suppliers ({
				shopName: this.shopName,
				contcName: this.contcName,
				houseNo: this.houseNo,
				roadNo: this.roadNo,
				state: this.state,
				district: this.district,
				phone: this.phone,
				email: this.email
			});

			// Redirect after save
			supplier.$save(function(response) {
				$location.path('suppliers/' + response._id);

				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Supplier
		$scope.remove = function(supplier) {
			if ( supplier ) { 
				supplier.$remove();

				for (var i in $scope.suppliers) {
					if ($scope.suppliers [i] === supplier) {
						$scope.suppliers.splice(i, 1);
					}
				}
			} else {
				$scope.supplier.$remove(function() {
					$location.path('suppliers');
				});
			}
		};

		// Update existing Supplier
		$scope.update = function() {
			var supplier = $scope.supplier;

			supplier.$update(function() {
				$location.path('suppliers/' + supplier._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		
		$scope.gridOptions = {
			 enableSorting: true,
			enableFiltering: true,
			
			//showGridFooter: true,
			showColumnFooter: true,
			
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,

			columnDefs: [
			  {field: 'shopName', displayName: 'ShopName'},
			  {field: 'email', displayName: 'Email'},
			 { name: 'more', displayName: 'more', cellTemplate: '<a data-ng-href="#!/suppliers/{{row.entity._id}}" >more</a> ', enableFiltering: false, enableSorting: false}
			]    
		  };
		  
		// Find a list of Dishes
		$scope.find = function() {
			$scope.suppliers = Suppliers.query();
			$scope.gridOptions.data = $scope.suppliers;	
		};
		

		// Find existing Supplier
		$scope.findOne = function() {
			$scope.supplier = Suppliers.get({ 
				supplierId: $stateParams.supplierId
			});
		};
	}
]);