'use strict';

// Orders controller
angular.module('orders').controller('OrdersController', ['$scope', '$http', '$rootScope', '$stateParams', '$location', 'Authentication', 'Orders',
	function($scope, $http, $rootScope, $stateParams, $location, Authentication, Orders) {
		$scope.authentication = Authentication;
		$scope.quantity='1';
		$rootScope.rootOrdrNo = $rootScope.rootOrdrNo || 0;
		$rootScope.rootTotal = $rootScope.rootTotal || 0;
		$scope.rating = $scope.dish.rating;
		console.log($scope.dish);
		// Create new Order
		this.create = function(dishOrder) {
			// Create new Order object
			$rootScope.rootOrdrNo += 1;
			
			var order = new Orders ({
				dishId: dishOrder._id,
				quantity: $scope.quantity
			});

			// Redirect after save
			order.$save(function(response) {
				//$location.path('orders/' + response._id);
				$rootScope.rootTotal += $scope.quantity*dishOrder.price;
				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
			
			//topbar add
			//var myEl = angular.element( document.querySelector( '#basket' ) );
			//myEl.append('<li><a href="#">'+dishOrder.dishName+'</a></li>');
		};

		// Remove existing Order
		$scope.remove = function(order) {
			if ( order ) { 
				order.$remove();

				for (var i in $scope.orders) {
					if ($scope.orders [i] === order) {
						$scope.orders.splice(i, 1);
					}
				}
			} else {
				$scope.order.$remove(function() {
					$location.path('orders');
				});
			}
		};

		// Update existing Order
		$scope.update = function() {
			var order = $scope.order;
			order.dishId.rating = $scope.rating;
				console.log(order);
			order.$update(function() {
				$location.path('orders/' + order._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};
		
		//rating method
		$scope.orderRating= function(){
			var rating= ($scope.dish.rating+$scope.rating)/2;
			$scope.dish.rating = rating;
			
			$http.post('/dishes/rating', $scope.dish).success(function(resdata) { //url must singele qoute
				
				
			}).error(function(response) {
				console.log('error');
				$scope.error = response.message;
			});
		};

		// Find a list of Orders
		$scope.find = function() {
			$scope.orders = Orders.query();
		};

		// Find existing Order
		$scope.findOne = function() {
			$scope.order = Orders.get({ 
				orderId: $stateParams.orderId
			});
		};
	}
]);

