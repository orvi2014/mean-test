'use strict';

// Mails controller
angular.module('mails').controller('MailsController', ['$scope', '$stateParams', '$location', 'Authentication', 'Mails',
	function($scope, $stateParams, $location, Authentication, Mails) {
		$scope.authentication = Authentication;

		// Create new Mail
		$scope.create = function() {
			// Create new Mail object
			var mail = new Mails ({
				name: this.name,
				email: this.email,
				phone: this.phone,
				message: this.message
				
			});

			// Redirect after save
			mail.$save(function(response) {
				$location.path('mails/' + response._id);

				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Mail
		$scope.remove = function(mail) {
			if ( mail ) { 
				mail.$remove();

				for (var i in $scope.mails) {
					if ($scope.mails [i] === mail) {
						$scope.mails.splice(i, 1);
					}
				}
			} else {
				$scope.mail.$remove(function() {
					$location.path('mails');
				});
			}
		};

		// Update existing Mail
		$scope.update = function() {
			var mail = $scope.mail;

			mail.$update(function() {
				$location.path('mails/' + mail._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		$scope.gridOptionsMail = {
			 enableSorting: true,
			enableFiltering: true,
			
			//showGridFooter: true,
			showColumnFooter: true,
			
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,
		
			columnDefs: [
			  {field: 'email', displayName: 'Email'},
			  {field: 'message', displayName: 'Message'},
			 { name: 'more', displayName: 'more', cellTemplate: '<a data-ng-href="#!/mails/{{row.entity._id}}" >more</a> ', enableFiltering: false, enableSorting: false}
			]    
		  };
		  
		// Find a list of Dishes
		$scope.find = function() {
			$scope.mails = Mails.query();
			$scope.gridOptionsMail.data = $scope.mails;	
		};

		// Find existing Mail
		$scope.findOne = function() {
			$scope.mail = Mails.get({ 
				mailId: $stateParams.mailId
			});
		};
	}
]);