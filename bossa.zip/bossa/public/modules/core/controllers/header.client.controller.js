'use strict';

angular.module('core').controller('HeaderController', ['$scope', '$rootScope', '$http', 'Authentication', 'Menus',
	function($scope, $rootScope, $http, Authentication, Menus ) {
		$scope.authentication = Authentication;
		$scope.isCollapsed = false;
		 
		$scope.menu = Menus.getMenu('topbar');
		//$scope.menu = Menus.getMenu('top-admin');
		
		/*setTimeout(function(){
			odometer.innerHTML = 456;
		}, 1000);*/

		$scope.toggleCollapsibleMenu = function() {
			$scope.isCollapsed = !$scope.isCollapsed;
		};

		// Collapsing the menu after navigation
		$scope.$on('$stateChangeSuccess', function() {
			$scope.isCollapsed = false;
		});
		
		//cart managment
		$scope.checkOut= function(){
			$http.get('/orders/cart').success(function(response) {
				$scope.total= 0;
				$scope.tpiece= 0;
				$scope.orders = response;
				console.log(response);
				var tot=0,tp=0;
				for(var i = 0; i < response.length; i++){
					 tot += parseFloat(response[i].dishId.price)*parseInt(response[i].quantity);
					 tp += parseInt(response[i].quantity);
					 $scope.total = tot;
					 $scope.tpiece= tp;
				}
				
			}).error(function(response) {
				$scope.error = response.message;
			});
		};
		
		$scope.remove = function(order,$event) {
			$http.delete('/orders/'+ order._id).success(function(response) {
				$rootScope.rootOrdrNo -= 1;
				$scope.orders = response;
				$rootScope.rootTotal -= order.quantity*order.dishId.price;
				if($event){
					$event.stopPropagation();
					$event.preventDefault();
				  }
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

	
	}
	
	
]);

$(document).ready(function () {
	$.material.init();
	
});

