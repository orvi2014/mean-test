'use strict';

angular.module('core').controller('HomeController', ['$scope', '$location', '$cookieStore', 'Authentication', 'Dishes', '$log', '$modal', 'Suppliers', 'Bookings',
	function($scope, $location,  $cookieStore, Authentication, Dishes, $log, $modal, Suppliers, Bookings ) {
		// This provides Authentication context.
		$scope.authentication = Authentication;
		$scope.supplier =$cookieStore.get('supplier');
		
		$scope.dishesb= $scope.dishesb || [];
		
		$scope.dtBk =$cookieStore.get('dtBk');
		$scope.psBk =$cookieStore.get('psBk');
		$scope.dsBk =$cookieStore.get('dsBk');
		
		
		//$scope.maxSize = 5;
		//$scope.bigTotalItems = Customers.length;
		
		$scope.currentPage = 0;
		$scope.currentPage1 = 1; //for parallel view
		$scope.pageSize = 9;
		$scope.numberOfPages=function(){
			return Math.ceil(Dishes.length/$scope.pageSize);                
		};
		
		
			

		$scope.find = function() {
			$scope.dishes = Dishes.query();
			$scope.suppliers = Suppliers.query();
		};
		
		$scope.setSupplier = function(supplier) {
			$cookieStore.remove('supplier');
			$cookieStore.put('supplier',supplier);
		};
		// open a modal
		// Register a body reference to use later
		//var bodyRef = angular.element( $document[0].body );
		$scope.open = function (size, dishUp) {
			// Add our overflow hidden class on opening
			//bodyRef.addClass('ovh');
			
			var modalInstance = $modal.open({
			  templateUrl: 'modules/orders/views/create-order.client.view.html',
			  controller: 'ModalInstanceCtrl',
			  windowClass: 'center-modal', //css
			  size: size,
			  resolve: {
				dish: function () {
				  return dishUp;
				}
			  }
			});
			
		
			modalInstance.result.then(function (selectedItem) {
				 // Remove it on closing
				//bodyRef.removeClass('ovh');
			  $scope.selected = selectedItem;
			}, function (){
				// Remove it on dismissal
				//bodyRef.removeClass('ovh');
			  $log.info('Modal dismissed at: ' + new Date());
			});
		};
		
		
		
//----------date time-------
		$scope.dt = new Date();
		$scope.minDate = $scope.minDate ? null : new Date();
		
		$scope.open1 = function($event) {
			$event.preventDefault();
			$event.stopPropagation();
		
			$scope.opened = true;
		  };
		  
//--------time-----
        var date = new Date();
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; // the hour '0' should be '12'
		minutes = minutes < 10 ? '0'+minutes : minutes;
		$scope.bookTime = hours + ':' + minutes + ' ' + ampm;//d.getTime();

		$('#t1').clockface();

//-------select------
		$scope.partySize= 2;
		$scope.tolatNo = 50;
		$scope.getNumber = function(num) {
			return new Array(num);   
		};
		
		//-------set time------
		
		
		
		$scope.setCrdnBook = function() {
			var startDateTime;

			$scope.bookTime = $('#t1').clockface('getTime');
			$('#t1').clockface('hide');
			
			var parts = /^(\d+):(\d+) (AM|PM)$/.exec($scope.bookTime);
			if (parts) {
				hours = parseInt(parts[1], 10);
				minutes = parseInt(parts[2], 10);
				if (parts[3] === 'PM' && hours !== 12) {
					hours += 12;
				}
				else if (parts[3] === 'AM' && hours === 12) {
					hours = 0;
				}
				if (!isNaN(hours) && !isNaN(minutes)) {
					startDateTime = new Date($scope.dt.getTime());
					startDateTime.setHours(hours);
					startDateTime.setMinutes(minutes);
				}
			}
			
			$scope.dt = new Date(startDateTime);
			$cookieStore.remove('dtBk');
			$cookieStore.put('dtBk',$scope.dt);
			$cookieStore.remove('psBk');
			$cookieStore.put('psBk',$scope.partySize);

		};
		
		$scope.book = function(size, restuarent) {
			$scope.setSupplier(restuarent);
			var modalInstance = $modal.open({
			  templateUrl: 'modules/bookings/views/create-booking.client.view.html',
			  controller: 'bookingCtrl',
			  windowClass: 'center-modal', //css
			  size: size
			});
			
		
			modalInstance.result.then(function (selectedItem) {
			  $scope.selected = selectedItem;
			}, function (){ 
			  $log.info('Modal dismissed at: ' + new Date());
			});

		};
		

		////add dish id
		//$scope.checkDishes = function(dish) {
		//	
		//	$scope.dishesb.push(dish);
		//	console.log('her in dish',$scope.dishesb, dish);
		//};
		
		//dish add chek for bookingh
		var tot=0;
		$scope.checkDishes = function(dish) {
		
			var idx = $scope.dishesb.indexOf(dish._id);
			
			if (idx > -1) {
				tot=tot - dish.price;
				$scope.dishesb.splice(idx, 1);
			} else {
				tot=tot + dish.price;
				$scope.dishesb.push(dish._id);
			}
			$scope.advBk = parseFloat(tot/2);
			$cookieStore.remove('dsBk');
			$cookieStore.put('dsBk',$scope.dishesb);
		};
		
		//paypal success	
		$scope.myParam=$location.search().tx;
		
		if ($scope.myParam) {
			
			var booking = new Bookings ({
				partySize: $scope.psBk,
				restuarent: $scope.supplier._id,
				bookDateTime: $scope.dtBk,
				dishes : $scope.dsBk,
				txId : $scope.myParam
			});
			
			booking.$save(function(response) {
			
				$modal.open({
					templateUrl:  'modules/orders/views/paypalsucc.html',
					//scope: $scope,
					controller: 'PaySuc',
					windowClass: 'center-modal'//, //css
					//resolve: {
					//  TxId : function () {
					//	return $scope.myParam;
					//  }
					//}
				});
			
			}, function(errorResponse) {
				if (confirm('already taken this payment') === true) {
				   $location.path('//');
			   } else {
				  $location.path('//');
			   }
				
			});
			
			$cookieStore.remove('dsBk');
			$cookieStore.remove('dtBk');
			$cookieStore.remove('psBk');
			
			
		}
		


	}
	
]);

angular.module('core').controller('PaySuc', function ($scope, $modalInstance, TxId) {

			$scope.TxId = TxId;
			
			$scope.ok = function () {
			  $modalInstance.close($scope.TxId);
			};
		  
			$scope.cancel = function () {
			  $modalInstance.dismiss('cancel');
			};
});

angular.module('core').controller('ModalInstanceCtrl', function ($scope, $modalInstance, dish) {

			$scope.dish = dish;
			
			$scope.swape = function(dish1) {
			$scope.dish = dish1;
		};
			$scope.ok = function () {
			  $modalInstance.close($scope.dish);
			};
		  
			$scope.cancel = function () {
			  $modalInstance.dismiss('cancel');
			};
});

angular.module('core').controller('bookingCtrl', function ($scope, $modalInstance) {

			
			$scope.ok = function () {
			  $modalInstance.close($scope.supplier);
			};
		  
			$scope.cancel = function () {
			  $modalInstance.dismiss('cancel');
			};
});

angular.module('core').filter('startFrom', function() {
		    return function(input, start) {
			start = +start; //parse to int
			return input.slice(start);
		    };
		});

