'use strict';

// Configuring the Articles module
angular.module('catagories').run(['Menus',
	function(Menus) {
		// Set top bar menu items
		//Menus.addMenuItem('topbar', 'Catagories', 'catagories', 'dropdown', '/catagories(/create)?');
		//Menus.addSubMenuItem('topbar', 'catagories', 'List Catagories', 'catagories');
		//Menus.addSubMenuItem('topbar', 'catagories', 'New Catagory', 'catagories/create');
	}
]);