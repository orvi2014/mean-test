'use strict';

//Setting up route
angular.module('catagories').config(['$stateProvider',
	function($stateProvider) {
		// Catagories state routing
		$stateProvider.
		state('listCatagories', {
			url: '/catagories',
			templateUrl: 'modules/catagories/views/list-catagories.client.view.html'
		}).
		state('createCatagory', {
			url: '/catagories/create',
			templateUrl: 'modules/catagories/views/create-catagory.client.view.html'
		}).
		state('viewCatagory', {
			url: '/catagories/:catagoryId',
			templateUrl: 'modules/catagories/views/view-catagory.client.view.html'
		}).
		state('editCatagory', {
			url: '/catagories/:catagoryId/edit',
			templateUrl: 'modules/catagories/views/edit-catagory.client.view.html'
		});
	}
]);