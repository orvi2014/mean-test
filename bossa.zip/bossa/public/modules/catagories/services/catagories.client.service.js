'use strict';

//Catagories service used to communicate Catagories REST endpoints
angular.module('catagories').factory('Catagories', ['$resource',
	function($resource) {
		return $resource('catagories/:catagoryId', { catagoryId: '@_id'
		}, {
			update: {
				method: 'PUT'
			}
		});
	}
]);