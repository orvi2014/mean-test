'use strict';

// Catagories controller
angular.module('catagories').controller('CatagoriesController', ['$scope', '$stateParams', '$location', 'Authentication', 'Catagories',
	function($scope, $stateParams, $location, Authentication, Catagories) {
		$scope.authentication = Authentication;

		// Create new Catagory
		$scope.create = function() {
			// Create new Catagory object
			var catagory = new Catagories ({
				name: this.name
			});

			// Redirect after save
			catagory.$save(function(response) {
				$location.path('catagories/' + response._id);

				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Catagory
		$scope.remove = function(catagory) {
			if ( catagory ) { 
				catagory.$remove();

				for (var i in $scope.catagories) {
					if ($scope.catagories [i] === catagory) {
						$scope.catagories.splice(i, 1);
					}
				}
			} else {
				$scope.catagory.$remove(function() {
					$location.path('catagories');
				});
			}
		};

		// Update existing Catagory
		$scope.update = function() {
			var catagory = $scope.catagory;

			catagory.$update(function() {
				$location.path('catagories/' + catagory._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Find a list of Catagories
		$scope.find = function() {
			$scope.catagories = Catagories.query();
		};

		// Find existing Catagory
		$scope.findOne = function() {
			$scope.catagory = Catagories.get({ 
				catagoryId: $stateParams.catagoryId
			});
		};
	}
]);