'use strict';

//Order details service used to communicate Order details REST endpoints
angular.module('order-details').factory('OrderDetails', ['$resource',
	function($resource) {
		return $resource('order-details/:orderDetailId', { orderDetailId: '@_id'
		}, {
			update: {
				method: 'PUT'
			}
		});
	}
]);