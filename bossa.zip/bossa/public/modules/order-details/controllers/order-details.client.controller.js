'use strict';

// Order details controller
angular.module('order-details').controller('OrderDetailsController', ['$scope', '$http', '$rootScope', '$stateParams', '$location', '$modal', 'Authentication', 'OrderDetails', 'uiGridConstants',
	function($scope, $http, $rootScope, $stateParams, $location, $modal, Authentication, OrderDetails, uiGridConstants) {
		$scope.authentication = Authentication;
		$scope.orderNo= null;
		$scope.pickupChk= 'formrslv';

		// Create new Order detail
		$scope.create = function() {
			
			var orderDetail = new OrderDetails ({
			orderNo: $scope.orderNo,
			paymentId: this.name,
			total: $scope.total,
			shipperId: this.name,
			shipHomeNo: this.houseNo,
			shipRoadNo: this.roadNo,
			shipArea: this.localArea,
			shipPo: this.postOffie,
			shipThan: this.thana,
			shipZip: this.zipCode,
			message: this.message,
			pickUp: this.pickUp
			});
			
		
			// Redirect after save
			orderDetail.$save(function(response) {
				
				$scope.success = 'Your Order Send Succsessfully !';
				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		 //Remove existing Order detail
		$scope.removeOrderDetails = function(orderDetail) {
			if ( orderDetail ) { 
				orderDetail.$remove();
		
				for (var i in $scope.orderDetails) {
					if ($scope.orderDetails [i] === orderDetail) {
						$scope.orderDetails.splice(i, 1);
					}
				}
			} else {
				$scope.orderDetail.$remove(function() {
					$location.path('order-details');
				});
			}
		};
		
		

		// Update existing Order detail
		$scope.update = function() {
			var orderDetail = $scope.orderDetail;

			orderDetail.$update(function() {
				$location.path('order-details/' + orderDetail._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		
		$scope.gridOptions = {
			 enableSorting: true,
			enableFiltering: true,
			
			//showGridFooter: true,
			showColumnFooter: true,
			
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,

			columnDefs: [
			  {field: 'orderNo', displayName: 'OrderNo'},
			  {field: 'total', displayName: 'Total', aggregationType: uiGridConstants.aggregationTypes.sum },
			 { name: 'more', displayName: 'more', cellTemplate: '<a data-ng-href="#!/order-details/{{row.entity._id}}" >more</a> ', enableFiltering: false, enableSorting: false}
			]    
		  };
		  
		// Find a list of Order details
		$scope.find = function() {
			$scope.orderDetails = OrderDetails.query();
			$scope.gridOptions.data = $scope.orderDetails;	
		};
		

		// Find existing Order detail
		$scope.findOne = function() {
			$scope.orderDetail = OrderDetails.get({ 
				orderDetailId: $stateParams.orderDetailId
			});
		};
		
		$scope.checkOut= function(){
			$http.get('/orders/cart').success(function(response) {
				
				$scope.tpiece= 0;
				$scope.orders = response;
				$scope.orderNo = response[0].orderNo;
			
				var tot=0,tp=0;
				for(var i = 0; i < response.length; i++){
					 tot += parseFloat(response[i].dishId.price)*parseInt(response[i].quantity);
					 tp += parseInt(response[i].quantity);
					 $scope.total = tot;
					 $scope.tpiece= tp;
				}
				
			}).error(function(response) {
				$scope.error = response.message;
			});
		};
		
		$scope.remove = function(order) {
			$http.delete('/orders/'+ order._id).success(function(response) {
				$rootScope.rootOrdrNo -= 1;
				$scope.orders = response;
				$rootScope.rootTotal -= order.quantity*order.dishId.price;
			}).error(function(response) {
				$scope.error = response.message;
			});
		};
		
		$scope.pick= function(){
				if (!$scope.pickUp) {
					$scope.pickupChk= 'formrchk';
				}else{
					$scope.pickupChk= 'formrslv';
				}
			};
			
		
	}
]);

//console.log(document.referrer , history.previous , window.location.href);
//$.cookie("previousUrl", window.location.href, {path:"/"}); // previus url