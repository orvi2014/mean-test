'use strict';

//Setting up route
angular.module('order-details').config(['$stateProvider',
	function($stateProvider) {
		// Order details state routing
		$stateProvider.
		state('listOrderDetails', {
			url: '/order-details',
			templateUrl: 'modules/order-details/views/list-order-details.client.view.html'
		}).
		state('createOrderDetail', {
			url: '/order-details/create',
			templateUrl: 'modules/order-details/views/create-order-detail.client.view.html'
		}).
		state('viewOrderDetail', {
			url: '/order-details/:orderDetailId',
			templateUrl: 'modules/order-details/views/view-order-detail.client.view.html'
		}).
		state('editOrderDetail', {
			url: '/order-details/:orderDetailId/edit',
			templateUrl: 'modules/order-details/views/edit-order-detail.client.view.html'
		});
	}
]);