'use strict';

// Configuring the Articles module
angular.module('order-details').run(['Menus',
	function(Menus) {
		// Set top bar menu items
		Menus.addMenuItem('topbar', 'Order details', 'order-details', 'dropdown', '/order-details(/create)?');
		Menus.addSubMenuItem('topbar', 'order-details', 'List Order details', 'order-details');
		//Menus.addSubMenuItem('topbar', 'order-details', 'New Order detail', 'order-details/create');
	}
]);