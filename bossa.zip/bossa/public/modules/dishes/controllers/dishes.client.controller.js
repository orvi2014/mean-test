'use strict';

// Dishes controller
angular.module('dishes').controller('DishesController', ['$scope', '$stateParams', '$location', 'Authentication', 'Dishes', 'Suppliers', 'uiGridConstants',
	function($scope, $stateParams, $location, Authentication, Dishes, Suppliers, uiGridConstants) {
		$scope.authentication = Authentication;

		// Create new Dish
		$scope.create = function() {
			// Create new Dish object
			var dish = new Dishes ({
				dishName: this.dishName,
				description: this.description,
				supplierId: this.supplierId,
				catagoryId: this.catagoryId,
				price: this.price,
				stock: this.stock,
				discount: this.discount,
				rating: this.rating,
				allergen: this.allergen
				
			});

			// Redirect after save
			dish.$save(function(response) {
				$location.path('dishes/' + response._id);

				// Clear form fields
				$scope.dishName = '';
				$scope.description = '';
				$scope.supplierId = '';
				$scope.catagoryId = '';
				$scope.price = '';
				$scope.stock = '';
				$scope.discount = '';
				$scope.rating = '';
				$scope.allergen = '';
				
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Dish
		$scope.remove = function(dish) {
			if ( dish ) { 
				dish.$remove();

				for (var i in $scope.dishes) {
					if ($scope.dishes [i] === dish) {
						$scope.dishes.splice(i, 1);
					}
				}
			} else {
				$scope.dish.$remove(function() {
					$location.path('dishes');
				});
			}
		};

		// Update existing Dish
		$scope.update = function() {
			var dish = $scope.dish;
			
			dish.$update(function() {
				$location.path('dishes/' + dish._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		//ui grid more
		$scope.gridOptions = {
			 enableSorting: true,
			enableFiltering: true,
			//showHeader: false,
			
			//showGridFooter: true,
			showColumnFooter: true,
			
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,

			columnDefs: [
			  {field: 'dishName', displayName: 'Name'},
			  {field: 'price', displayName: 'price', aggregationType: uiGridConstants.aggregationTypes.sum },
			 { name: 'more', displayName: 'more', cellTemplate: '<a data-ng-href="#!/dishes/{{row.entity._id}}" >more</a> ', enableFiltering: false, enableSorting: false}
			]    
		  };
		  
		// Find a list of Dishes
		$scope.find = function() {
			$scope.dishes = Dishes.query();
			$scope.gridOptions.data = $scope.dishes;	
		};

		$scope.findSupplier = function() {
			$scope.suppliers = Suppliers.query();
		};
		
		// Find existing Dish
		$scope.findOne = function() {
			$scope.dish = Dishes.get({ 
				dishId: $stateParams.dishId
			});
		};
	//filter duggetion
		$scope.lessThan = function(prop, val){
			return function(item){
			  return item[prop] < val;
			};
		};
		
		$scope.items = [{ 'id':123, 'color':'red'},{ 'id':13, 'color':'blue'}, { 'id':323,'color':'green'}];
		
		
	}
]);