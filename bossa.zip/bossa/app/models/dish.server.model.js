'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Dish Schema
 */
var DishSchema = new Schema({
	dishName: {
		type: String,
		default: '',
		required: 'Please fill Dishname',
		trim: true
	},
	description: {
		type: String,
		default: 'lorem Ipsum is simply dummy text of the printing and typesetting industry.',
		trim: true
	},
	supplierId: {
		type: Schema.ObjectId,
		ref: 'Supplier'
	},
	catagoryId: {
		type: String,
		default: '',
		//required: 'Please fill CatagoryId',
		trim: true
	},
	price: {
		type: Number,
		default: '',
		required: 'Please fill Price',
		trim: true
	},
	stock: {
		type: Number,
		default: 1,
		//required: 'Please fill Stock',
		trim: true
	},
	rating: {
		type: Number,
		default: 4,
		trim: true
	},
	allergen: {
		type: String,
		default: '1,4,12',
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Dish', DishSchema);