'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Catagory Schema
 */
var CatagorySchema = new Schema({
	name: {
		type: String,
		default: '',
		required: 'Please fill Catagory name',
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Catagory', CatagorySchema);