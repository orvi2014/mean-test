'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Order Schema
 */
var OrderSchema = new Schema({
	orderNo: {
		type: Number,
		default: '',
		//required: 'Please fill Order name',
		trim: true
	},
	dishId: {
		type: Schema.ObjectId,
		ref: 'Dish'
	},
	quantity: {
		type: Number,
		default: '1',
		required: 'Please fill Order name',
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Order', OrderSchema);