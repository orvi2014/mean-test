'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Mail Schema
 */
var MailSchema = new Schema({
	name: {
		type: String,
		default: '',
		required: 'Please fill name',
		trim: true
	},
	email: {
		type: String,
		default: '',
		required: 'Please fill Mail name',
		trim: true,
		match: [/.+\@.+\..+/, 'Please fill a valid email address']
	},
	phone: {
		type: String,
		default: '',
		required: 'Please fill phone no',
		trim: true,
		match: [/\d{3}-\d{3}-\d{4}|\d{10}/ , 'Please fill a valid phone no']
	},
	message: {
		type: String,
		default: '',
		required: 'Please fill message name',
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Mail', MailSchema);