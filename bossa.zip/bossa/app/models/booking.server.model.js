'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Booking Schema
 */
var BookingSchema = new Schema({
	txId : {
		type: String,
		required: 'txid reQuire',
		trim: true,
		unique: true
	},
	partySize: {
		type: Number,
		default: 1,
		required: 'Please fill Party Size',
		trim: true
	},
	restuarent: {
		type: Schema.ObjectId,
		ref: 'Supplier'
	},
	dishes: [{
		type: Schema.ObjectId,
		ref: 'Dish'
	}],
	bookDateTime: {
		type: Date,
		default: Date.now
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Booking', BookingSchema);