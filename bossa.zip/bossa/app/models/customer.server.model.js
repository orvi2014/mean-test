'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Customer Schema
 */
var CustomerSchema = new Schema({
	fName: {
		type: String,
		default: '',
		required: 'Please fill firstName',
		trim: true
	},
	lName: {
		type: String,
		default: '',
		required: 'Please fill  lastName',
		trim: true
	},
	password: {
		type: String,
		default: '',
		required: 'Please fill  password',
		trim: true
	},
	userName: {
		type: String,
		default: '',
		required: 'Please fill username',
		trim: true
	},
	houseNo :{
	type: String,
	default: '',
	
	trim: true
	},
	roadNo :{
	type: String,
	default: '',
	
	trim: true
	},
	state :{
	type: String,
	default: '',
	
	trim: true
	},
	district :{
	type: String,
	default: '',
	
	trim: true
	},
	phone :{
	type: Number,
	default: '',
	
	trim: true
	},
	email :{
	type: String,
	default: '',
	required: 'Please fill email',
	trim: true
	},
	
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Customer', CustomerSchema);