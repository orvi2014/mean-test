'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Order detail Schema
 */
var OrderDetailSchema = new Schema({
	orderNo: {
		type: String,
		default: '',
		required: 'u diidn select any item',
		trim: true
	},
	paymentId: {
		type: String,
		default: '',
			
		trim: true
	},
	total: {
		type: Number,
		default: '',
		required: 'u diidn select any item',
		trim: true
	},
	shipperId: {
		type: String,
		default: '',
			
		trim: true
	},
	//addrs
	shipHomeNo: {
		type: String,
		default: '',
		
		trim: true
	},
	shipRoadNo: {
		type: String,
		default: '',
		
		trim: true
	},
	shipArea: {
		type: String,
		default: '',
		trim: true
	},
	shipPo: {
		type: String,
		default: '',
	
		trim: true
	},
	shipThan: {
		type: String,
		default: '',
	
		trim: true
	},
	shipZip: {
		type: String,
		default: '',
		
		trim: true
	},
	message: {
		type: String,
		default: '',
	
		trim: true
	},
	pickUp : {
		type: Boolean,
		default: false,
		
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('OrderDetail', OrderDetailSchema);