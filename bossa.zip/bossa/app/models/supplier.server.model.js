'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

/**
 * Supplier Schema
 */
var SupplierSchema = new Schema({
	shopName: {
		type: String,
		default: '',
		required: 'Please fill Supplier name',
		trim: true
	},
	contcName: {
		type: String,
		default: '',
		
		trim: true
	},
	catagory :{
		type: String,
		default: '',
	
		trim: true
	},
	rating: {
		type: Number,
		default: 4,

		trim: true
	},
	address :{
		type: String,
		default: '',
	
		trim: true
	},
	district :{
		type: String,
		default: '',
		
		trim: true
	},
	phone :{
		type: String,
		default: '',
		required: 'Please fill phone',
		trim: true
	},
	email :{
		type: String,
		default: '',
		
		trim: true
	},
	created: {
		type: Date,
		default: Date.now
	},
	user: {
		type: Schema.ObjectId,
		ref: 'User'
	}
});

mongoose.model('Supplier', SupplierSchema);