'use strict';

module.exports = function(app) {
	var users = require('../../app/controllers/users.server.controller');
	var orderDetails = require('../../app/controllers/order-details.server.controller');

	// Order details Routes
	app.route('/order-details')
		.get(users.requiresLogin, orderDetails.list)
		.post(users.requiresLogin, orderDetails.create);

	app.route('/order-details/:orderDetailId')
		.get(orderDetails.read)
		.put(users.requiresLogin, orderDetails.hasAuthorization, orderDetails.update)
		.delete(users.requiresLogin, orderDetails.hasAuthorization, orderDetails.delete);

	// Finish by binding the Order detail middleware
	app.param('orderDetailId', orderDetails.orderDetailByID);
};
