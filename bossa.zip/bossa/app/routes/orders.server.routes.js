'use strict';

module.exports = function(app) {
	var users = require('../../app/controllers/users.server.controller');
	var orders = require('../../app/controllers/orders.server.controller');

	// Orders Routes
	app.route('/orders')
		.get(orders.list)
		.post(users.requiresLogin, orders.create);
		
	app.route('/orders/cart')
		.get(users.requiresLogin, orders.listcart);
		
	app.route('/orders/:orderId')
		.get(orders.read)
		.put(users.requiresLogin, orders.hasAuthorization, orders.update)
		.delete(users.requiresLogin, orders.hasAuthorization, orders.delete);
		
	app.route('/orders/cart')
		.get(orders.listcart);
	// Finish by binding the Order middleware
	app.param('orderId', orders.orderByID);
};
