'use strict';

module.exports = function(app) {
	var users = require('../../app/controllers/users.server.controller');
	var catagories = require('../../app/controllers/catagories.server.controller');

	// Catagories Routes
	app.route('/catagories')
		.get(catagories.list)
		.post(users.requiresLogin, catagories.create);

	app.route('/catagories/:catagoryId')
		.get(catagories.read)
		.put(users.requiresLogin, catagories.hasAuthorization, catagories.update)
		.delete(users.requiresLogin, catagories.hasAuthorization, catagories.delete);

	// Finish by binding the Catagory middleware
	app.param('catagoryId', catagories.catagoryByID);
};
