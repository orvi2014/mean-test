'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	errorHandler = require('./errors.server.controller'),
	Catagory = mongoose.model('Catagory'),
	_ = require('lodash');

/**
 * Create a Catagory
 */
exports.create = function(req, res) {
	var catagory = new Catagory(req.body);
	catagory.user = req.user;

	catagory.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(catagory);
		}
	});
};

/**
 * Show the current Catagory
 */
exports.read = function(req, res) {
	res.jsonp(req.catagory);
};

/**
 * Update a Catagory
 */
exports.update = function(req, res) {
	var catagory = req.catagory ;

	catagory = _.extend(catagory , req.body);

	catagory.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(catagory);
		}
	});
};

/**
 * Delete an Catagory
 */
exports.delete = function(req, res) {
	var catagory = req.catagory ;

	catagory.remove(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(catagory);
		}
	});
};

/**
 * List of Catagories
 */
exports.list = function(req, res) { 
	Catagory.find().sort('-created').populate('user', 'displayName').exec(function(err, catagories) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(catagories);
		}
	});
};

/**
 * Catagory middleware
 */
exports.catagoryByID = function(req, res, next, id) { 
	Catagory.findById(id).populate('user', 'displayName').exec(function(err, catagory) {
		if (err) return next(err);
		if (! catagory) return next(new Error('Failed to load Catagory ' + id));
		req.catagory = catagory ;
		next();
	});
};

/**
 * Catagory authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
	if (req.catagory.user.id !== req.user.id) {
		return res.status(403).send('User is not authorized');
	}
	next();
};
