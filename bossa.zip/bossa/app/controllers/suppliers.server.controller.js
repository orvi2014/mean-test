'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	fse = require('fs-extra'),
	XLSX = require('xlsx'),
	errorHandler = require('./errors.server.controller'),
	Supplier = mongoose.model('Supplier'),
	_ = require('lodash');

/**
 * Create a Supplier
 */
exports.create = function(req, res) {

	//my boss xlsx
	var supplier;
	
if(req.files)
	{
	
	var workbook = XLSX.readFile('./uploads/'+req.files.userPhoto.name);
	var sheet_name_list = workbook.SheetNames;
	sheet_name_list.forEach(function(y) {
		var worksheet = workbook.Sheets[y];
		var headers = {};
		var data = [];
		var z;
		for(z in worksheet) {
			if(z[0] === '!') continue;
			//parse out the column, row, and value
			var col = z.substring(0,1);
			var row = parseInt(z.substring(1));
			var value = worksheet[z].v;
			//console.log(col, row, value );
			//store header names
			if(row === 1) {
				try {
					headers[col] = value.trim();
				} catch (e) {
					// invalid json input, set to null
					headers[col] = value;
				}
				continue;
			}
	
			if(!data[row]) data[row]={};
			
			try {
				try {
					data[row][headers[col]] = value.trim().replace(/(\r\n|\n|\r|\&#10;)/gm,'');
				} catch(e) {
					data[row][headers[col]] = value.trim();
				}
				
			} catch (e) {
				// invalid json input, set to null
				try {
					data[row][headers[col]] = value.replace(/(\r\n|\n|\r|\&#10;)/gm,'');
				} catch(e) {
					data[row][headers[col]] = value;
				}
				
			}

		}
		//drop those first two rows which are empty
		data.shift();
		data.shift();
		//
		for(var k in data) {
			supplier = new Supplier(data[k]);
			supplier.user = req.user;
			
			supplier.save(function(err) {
				if (err) {
					console.log('error');
				} else {
					console.log('succ');
				}
			});
			//console.log(k, data[k]);
		 }
		
		//console.log(data);
		console.log('hola');
	});
	
}else{

	// node -xlsx
	//var obj = nxlsx.parse('./uploads/'+req.files.userPhoto.name);
	//console.log(req.files , JSON.parse(JSON.stringify(obj[0].data)));
	
	
	supplier = new Supplier(req.body);
	//var supplier = new Supplier(data);
	supplier.user = req.user;
	
	//fse.remove('./uploads/'+req.files.userPhoto.name , function (err) {
	//	if (err)
	//		return console.error(err);
	//  
	//	console.log('success!');
	//  });
	
	supplier.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(supplier);
		}
	});
}
};

/**
 * Show the current Supplier
 */
exports.read = function(req, res) {
	res.jsonp(req.supplier);
};

/**
 * Update a Supplier
 */
exports.update = function(req, res) {
	var supplier = req.supplier ;

	supplier = _.extend(supplier , req.body);

	supplier.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(supplier);
		}
	});
};

/**
 * Delete an Supplier
 */
exports.delete = function(req, res) {
	var supplier = req.supplier ;

	supplier.remove(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(supplier);
		}
	});
};

/**
 * List of Suppliers
 */
exports.list = function(req, res) { 
	Supplier.find().sort('-created').populate('user', 'displayName').exec(function(err, suppliers) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(suppliers);
		}
	});
};

/**
 * Supplier middleware
 */
exports.supplierByID = function(req, res, next, id) { 
	Supplier.findById(id).populate('user', 'displayName').exec(function(err, supplier) {
		if (err) return next(err);
		if (! supplier) return next(new Error('Failed to load Supplier ' + id));
		req.supplier = supplier ;
		next();
	});
};

/**
 * Supplier authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
	if ( req.user.roles[0] !== 'admin') {
		return res.status(403).send('User is not authorized');
	}
	next();
};
