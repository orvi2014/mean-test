'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	errorHandler = require('./errors.server.controller'),
	OrderDetail = mongoose.model('OrderDetail'),
	_ = require('lodash');

/**
 * Create a Order detail
 */
exports.create = function(req, res) {
	console.log(req.body);
	var orderDetail = new OrderDetail(req.body);
	orderDetail.user = req.user;

	orderDetail.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(orderDetail);
		}
	});
};

/**
 * Show the current Order detail
 */
exports.read = function(req, res) {
	res.jsonp(req.orderDetail);
};

/**
 * Update a Order detail
 */
exports.update = function(req, res) {
	var orderDetail = req.orderDetail ;

	orderDetail = _.extend(orderDetail , req.body);

	orderDetail.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(orderDetail);
		}
	});
};

/**
 * Delete an Order detail
 */
exports.delete = function(req, res) {
	var orderDetail = req.orderDetail ;

	orderDetail.remove(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(orderDetail);
		}
	});
};

/**
 * List of Order details
 */
exports.list = function(req, res) {
	
	//console.log(req.get('Referrer'));
	OrderDetail.find().sort('-created').populate('user', 'displayName').exec(function(err, orderDetails) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(orderDetails);
		}
	});
};

/**
 * Order detail middleware
 */
exports.orderDetailByID = function(req, res, next, id) { 
	OrderDetail.findById(id).populate('user', 'displayName').exec(function(err, orderDetail) {
		if (err) return next(err);
		if (! orderDetail) return next(new Error('Failed to load Order detail ' + id));
		req.orderDetail = orderDetail ;
		next();
	});
};

/**
 * Order detail authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
	if ( req.user.roles[0] !== 'admin') {
		return res.status(403).send('User is not authorized');
	}
	next();
};
