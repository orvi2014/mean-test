'use strict';

var should = require('should'),
	request = require('supertest'),
	app = require('../../server'),
	mongoose = require('mongoose'),
	User = mongoose.model('User'),
	Catagory = mongoose.model('Catagory'),
	agent = request.agent(app);

/**
 * Globals
 */
var credentials, user, catagory;

/**
 * Catagory routes tests
 */
describe('Catagory CRUD tests', function() {
	beforeEach(function(done) {
		// Create user credentials
		credentials = {
			username: 'username',
			password: 'password'
		};

		// Create a new user
		user = new User({
			firstName: 'Full',
			lastName: 'Name',
			displayName: 'Full Name',
			email: 'test@test.com',
			username: credentials.username,
			password: credentials.password,
			provider: 'local'
		});

		// Save a user to the test db and create new Catagory
		user.save(function() {
			catagory = {
				name: 'Catagory Name'
			};

			done();
		});
	});

	it('should be able to save Catagory instance if logged in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Catagory
				agent.post('/catagories')
					.send(catagory)
					.expect(200)
					.end(function(catagorySaveErr, catagorySaveRes) {
						// Handle Catagory save error
						if (catagorySaveErr) done(catagorySaveErr);

						// Get a list of Catagories
						agent.get('/catagories')
							.end(function(catagoriesGetErr, catagoriesGetRes) {
								// Handle Catagory save error
								if (catagoriesGetErr) done(catagoriesGetErr);

								// Get Catagories list
								var catagories = catagoriesGetRes.body;

								// Set assertions
								(catagories[0].user._id).should.equal(userId);
								(catagories[0].name).should.match('Catagory Name');

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should not be able to save Catagory instance if not logged in', function(done) {
		agent.post('/catagories')
			.send(catagory)
			.expect(401)
			.end(function(catagorySaveErr, catagorySaveRes) {
				// Call the assertion callback
				done(catagorySaveErr);
			});
	});

	it('should not be able to save Catagory instance if no name is provided', function(done) {
		// Invalidate name field
		catagory.name = '';

		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Catagory
				agent.post('/catagories')
					.send(catagory)
					.expect(400)
					.end(function(catagorySaveErr, catagorySaveRes) {
						// Set message assertion
						(catagorySaveRes.body.message).should.match('Please fill Catagory name');
						
						// Handle Catagory save error
						done(catagorySaveErr);
					});
			});
	});

	it('should be able to update Catagory instance if signed in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Catagory
				agent.post('/catagories')
					.send(catagory)
					.expect(200)
					.end(function(catagorySaveErr, catagorySaveRes) {
						// Handle Catagory save error
						if (catagorySaveErr) done(catagorySaveErr);

						// Update Catagory name
						catagory.name = 'WHY YOU GOTTA BE SO MEAN?';

						// Update existing Catagory
						agent.put('/catagories/' + catagorySaveRes.body._id)
							.send(catagory)
							.expect(200)
							.end(function(catagoryUpdateErr, catagoryUpdateRes) {
								// Handle Catagory update error
								if (catagoryUpdateErr) done(catagoryUpdateErr);

								// Set assertions
								(catagoryUpdateRes.body._id).should.equal(catagorySaveRes.body._id);
								(catagoryUpdateRes.body.name).should.match('WHY YOU GOTTA BE SO MEAN?');

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should be able to get a list of Catagories if not signed in', function(done) {
		// Create new Catagory model instance
		var catagoryObj = new Catagory(catagory);

		// Save the Catagory
		catagoryObj.save(function() {
			// Request Catagories
			request(app).get('/catagories')
				.end(function(req, res) {
					// Set assertion
					res.body.should.be.an.Array.with.lengthOf(1);

					// Call the assertion callback
					done();
				});

		});
	});


	it('should be able to get a single Catagory if not signed in', function(done) {
		// Create new Catagory model instance
		var catagoryObj = new Catagory(catagory);

		// Save the Catagory
		catagoryObj.save(function() {
			request(app).get('/catagories/' + catagoryObj._id)
				.end(function(req, res) {
					// Set assertion
					res.body.should.be.an.Object.with.property('name', catagory.name);

					// Call the assertion callback
					done();
				});
		});
	});

	it('should be able to delete Catagory instance if signed in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Catagory
				agent.post('/catagories')
					.send(catagory)
					.expect(200)
					.end(function(catagorySaveErr, catagorySaveRes) {
						// Handle Catagory save error
						if (catagorySaveErr) done(catagorySaveErr);

						// Delete existing Catagory
						agent.delete('/catagories/' + catagorySaveRes.body._id)
							.send(catagory)
							.expect(200)
							.end(function(catagoryDeleteErr, catagoryDeleteRes) {
								// Handle Catagory error error
								if (catagoryDeleteErr) done(catagoryDeleteErr);

								// Set assertions
								(catagoryDeleteRes.body._id).should.equal(catagorySaveRes.body._id);

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should not be able to delete Catagory instance if not signed in', function(done) {
		// Set Catagory user 
		catagory.user = user;

		// Create new Catagory model instance
		var catagoryObj = new Catagory(catagory);

		// Save the Catagory
		catagoryObj.save(function() {
			// Try deleting Catagory
			request(app).delete('/catagories/' + catagoryObj._id)
			.expect(401)
			.end(function(catagoryDeleteErr, catagoryDeleteRes) {
				// Set message assertion
				(catagoryDeleteRes.body.message).should.match('User is not logged in');

				// Handle Catagory error error
				done(catagoryDeleteErr);
			});

		});
	});

	afterEach(function(done) {
		User.remove().exec();
		Catagory.remove().exec();
		done();
	});
});