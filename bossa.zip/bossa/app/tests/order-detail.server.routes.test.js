'use strict';

var should = require('should'),
	request = require('supertest'),
	app = require('../../server'),
	mongoose = require('mongoose'),
	User = mongoose.model('User'),
	OrderDetail = mongoose.model('OrderDetail'),
	agent = request.agent(app);

/**
 * Globals
 */
var credentials, user, orderDetail;

/**
 * Order detail routes tests
 */
describe('Order detail CRUD tests', function() {
	beforeEach(function(done) {
		// Create user credentials
		credentials = {
			username: 'username',
			password: 'password'
		};

		// Create a new user
		user = new User({
			firstName: 'Full',
			lastName: 'Name',
			displayName: 'Full Name',
			email: 'test@test.com',
			username: credentials.username,
			password: credentials.password,
			provider: 'local'
		});

		// Save a user to the test db and create new Order detail
		user.save(function() {
			orderDetail = {
				name: 'Order detail Name'
			};

			done();
		});
	});

	it('should be able to save Order detail instance if logged in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Order detail
				agent.post('/order-details')
					.send(orderDetail)
					.expect(200)
					.end(function(orderDetailSaveErr, orderDetailSaveRes) {
						// Handle Order detail save error
						if (orderDetailSaveErr) done(orderDetailSaveErr);

						// Get a list of Order details
						agent.get('/order-details')
							.end(function(orderDetailsGetErr, orderDetailsGetRes) {
								// Handle Order detail save error
								if (orderDetailsGetErr) done(orderDetailsGetErr);

								// Get Order details list
								var orderDetails = orderDetailsGetRes.body;

								// Set assertions
								(orderDetails[0].user._id).should.equal(userId);
								(orderDetails[0].name).should.match('Order detail Name');

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should not be able to save Order detail instance if not logged in', function(done) {
		agent.post('/order-details')
			.send(orderDetail)
			.expect(401)
			.end(function(orderDetailSaveErr, orderDetailSaveRes) {
				// Call the assertion callback
				done(orderDetailSaveErr);
			});
	});

	it('should not be able to save Order detail instance if no name is provided', function(done) {
		// Invalidate name field
		orderDetail.name = '';

		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Order detail
				agent.post('/order-details')
					.send(orderDetail)
					.expect(400)
					.end(function(orderDetailSaveErr, orderDetailSaveRes) {
						// Set message assertion
						(orderDetailSaveRes.body.message).should.match('Please fill Order detail name');
						
						// Handle Order detail save error
						done(orderDetailSaveErr);
					});
			});
	});

	it('should be able to update Order detail instance if signed in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Order detail
				agent.post('/order-details')
					.send(orderDetail)
					.expect(200)
					.end(function(orderDetailSaveErr, orderDetailSaveRes) {
						// Handle Order detail save error
						if (orderDetailSaveErr) done(orderDetailSaveErr);

						// Update Order detail name
						orderDetail.name = 'WHY YOU GOTTA BE SO MEAN?';

						// Update existing Order detail
						agent.put('/order-details/' + orderDetailSaveRes.body._id)
							.send(orderDetail)
							.expect(200)
							.end(function(orderDetailUpdateErr, orderDetailUpdateRes) {
								// Handle Order detail update error
								if (orderDetailUpdateErr) done(orderDetailUpdateErr);

								// Set assertions
								(orderDetailUpdateRes.body._id).should.equal(orderDetailSaveRes.body._id);
								(orderDetailUpdateRes.body.name).should.match('WHY YOU GOTTA BE SO MEAN?');

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should be able to get a list of Order details if not signed in', function(done) {
		// Create new Order detail model instance
		var orderDetailObj = new OrderDetail(orderDetail);

		// Save the Order detail
		orderDetailObj.save(function() {
			// Request Order details
			request(app).get('/order-details')
				.end(function(req, res) {
					// Set assertion
					res.body.should.be.an.Array.with.lengthOf(1);

					// Call the assertion callback
					done();
				});

		});
	});


	it('should be able to get a single Order detail if not signed in', function(done) {
		// Create new Order detail model instance
		var orderDetailObj = new OrderDetail(orderDetail);

		// Save the Order detail
		orderDetailObj.save(function() {
			request(app).get('/order-details/' + orderDetailObj._id)
				.end(function(req, res) {
					// Set assertion
					res.body.should.be.an.Object.with.property('name', orderDetail.name);

					// Call the assertion callback
					done();
				});
		});
	});

	it('should be able to delete Order detail instance if signed in', function(done) {
		agent.post('/auth/signin')
			.send(credentials)
			.expect(200)
			.end(function(signinErr, signinRes) {
				// Handle signin error
				if (signinErr) done(signinErr);

				// Get the userId
				var userId = user.id;

				// Save a new Order detail
				agent.post('/order-details')
					.send(orderDetail)
					.expect(200)
					.end(function(orderDetailSaveErr, orderDetailSaveRes) {
						// Handle Order detail save error
						if (orderDetailSaveErr) done(orderDetailSaveErr);

						// Delete existing Order detail
						agent.delete('/order-details/' + orderDetailSaveRes.body._id)
							.send(orderDetail)
							.expect(200)
							.end(function(orderDetailDeleteErr, orderDetailDeleteRes) {
								// Handle Order detail error error
								if (orderDetailDeleteErr) done(orderDetailDeleteErr);

								// Set assertions
								(orderDetailDeleteRes.body._id).should.equal(orderDetailSaveRes.body._id);

								// Call the assertion callback
								done();
							});
					});
			});
	});

	it('should not be able to delete Order detail instance if not signed in', function(done) {
		// Set Order detail user 
		orderDetail.user = user;

		// Create new Order detail model instance
		var orderDetailObj = new OrderDetail(orderDetail);

		// Save the Order detail
		orderDetailObj.save(function() {
			// Try deleting Order detail
			request(app).delete('/order-details/' + orderDetailObj._id)
			.expect(401)
			.end(function(orderDetailDeleteErr, orderDetailDeleteRes) {
				// Set message assertion
				(orderDetailDeleteRes.body.message).should.match('User is not logged in');

				// Handle Order detail error error
				done(orderDetailDeleteErr);
			});

		});
	});

	afterEach(function(done) {
		User.remove().exec();
		OrderDetail.remove().exec();
		done();
	});
});